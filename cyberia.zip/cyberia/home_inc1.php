
	<div style="text-align:center;width:960px;margin-left: auto ;
  margin-right: auto ;">
       <div style="display:inline-block;"><img src="logo1.png" style="height:130px;width:130px;padding-bottom:10px;padding-right:20px;"></div>
 <div style=" display:inline-block;"><img src="logo2.png" style="height:80px;width:530px;padding-bottom:35px;padding-right:20px;"></div>
 <div style=" display:inline-block;"><img src="logo3.png" style="height:160px;width:170px"></div>
</div>   
