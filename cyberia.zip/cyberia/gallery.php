<!DOCTYPE html>
<head>
<link rel="shortcut icon" href="ieee_favicon.ico" type="image/x-icon" /> 
   <link rel="stylesheet" href="style.css" type="text/css" media="all">
</head>
<body>
<?php include 'home_inc.php'; ?>
<br><h1 style="text-align:center;margin:auto;color:white">GALLERY</h1>
<br>


<iframe src="/main/cyb/index.html" style="width:900px;height:450px;max-width:100%;overflow:hidden;border:none;padding:0;margin:0 auto;display:block;" marginheight="0" marginwidth="0"></iframe>
<br>

<?php include 'foot_inc.php'; ?> 
</body>
</html>