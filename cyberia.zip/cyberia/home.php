<!DOCTYPE html>
<head>
<link rel="shortcut icon" href="ieee_favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="style.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="iframe.css">
<style>


body {
background-image: url('back.png');
background-color:black;
background-repeat:no-repeat;
//background-attachment:fixed;
background-position:center;

}


</style>
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" />
        <link rel="stylesheet" href="assets/css/styles.css" />
        <link rel="stylesheet" href="assets/countdown/jquery.countdown.css" />
        
        <!--[if lt IE 9]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
</head>
<body>
/*="http://code.jquery.com/*/
<script src="jquery-1.7.2.min.js"></script>
		<script src="assets/countdown/jquery.countdown.js"></script>
		<script src="assets/js/script.js"></script>
<?php include 'home_inc1.php'; ?>

<div style="margin-left: auto ;
  margin-right: auto ;width:600px">
<iframe width="630" height="620" src="hex1.html" scrolling="no" frameborder="0" ></iframe></div>
<div id="countdown"></div>

		<p id="note"></p>

<br>
<?php include 'foot_inc1.php'; ?> 
</body>
</html>