<div class="foot" ><br>
<div style="display:inline-block;"><img src="logoieee.png" style="height:30px;width:80px;padding-bottom:20px;"></div>
 <div style=" display:inline-block;height:80px;width:450px"><ul class="f1">

<li class="f2" ><a href="home.php" style="color:white">
Home </a>
</li>

<li class="f2"><a href="http://ieeesjce.com" target="_blank"  style="color:white">
IEEEsjce.com</a></li>

<li class="f2"><a href="http://ieeesjce.com" target="_blank" style="color:white">
About IEEE</a></li>

<li><a href="#" style="color:white">
About Cyberia
</a></li>

</ul>

Designed and Maintained by Web Designing Board , IEEE-SJCE<br>&#169; Copyright 2013-2014 IEEE-SJCE All Rights Reserved.</div>

</div>
