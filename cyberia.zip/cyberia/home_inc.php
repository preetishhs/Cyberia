
	<div style="text-align:center;width:960px;margin-left: auto ;
  margin-right: auto ;">
       <div style="display:inline-block;"><img src="logo1.png" style="height:150px;width:130px;padding-bottom:10px;padding-right:20px;"></div>
 <div style=" display:inline-block;"><img src="logo2.png" style="height:90px;width:550px;padding-bottom:35px;padding-right:20px;"></div>
 <div style=" display:inline-block;"><img src="logo3.png" style="height:180px;width:170px"></div>
</div>   

<br>
<div class="example">
    <div class="menuholder">
        <ul class="menu slide">
            <li><a href="home.php" class="red">Home</a></li>
            <li><a href="event.php" class="orange">Events</a>
            </li>
            <li><a href="gallery.php" class="yellow">Gallery</a>
            </li>
            <li><a href="travel.php" class="green">Travel</a></li>
            <li><a href="sponsor.php" class="blue">Sponsors</a></li>
            <li><a href="contact.php" class="violet">Contact</a></li>
        </ul>
        <div class="shadow"></div>
    </div>
 </div>